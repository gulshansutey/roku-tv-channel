m is component scope
xml is the scene graph component
Each xml scene graph file has its coresponding brs file which defines the behaviour

